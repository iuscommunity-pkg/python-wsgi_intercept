
"""work intercepted HTTP connectsion in a webunit test case.

(see wsgi_intercept/__init__.py for examples)
            
"""
from webunittest import WebTestCase
__version__ = '1.3.8'
