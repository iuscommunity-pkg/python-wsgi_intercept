
"""intercept http requests made using the urllib2 module.

(see wsgi_intercept/__init__.py for examples)

"""
from wsgi_urllib2 import *