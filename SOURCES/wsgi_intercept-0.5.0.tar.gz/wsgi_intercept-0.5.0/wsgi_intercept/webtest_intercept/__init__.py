"""work with an intercepted HTTP connection in a webtest.WebCase

(see wsgi_intercept/__init__.py for examples)

"""

from webtest import *