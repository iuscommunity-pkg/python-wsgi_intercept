"""intercept connections made using a mechanoid Browser.

(see wsgi_intercept/__init__.py for examples)

"""
from wsgi_browser import Browser