"""intercepting HTTP connections made using zope.testbrowser.

(see wsgi_intercept/__init__.py for examples)

"""
from wsgi_testbrowser import WSGI_Browser