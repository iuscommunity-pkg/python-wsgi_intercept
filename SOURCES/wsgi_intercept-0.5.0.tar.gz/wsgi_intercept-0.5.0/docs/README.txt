
Build docs as HTML with:: 

    python setup.py build_docs

To publish docs to stdout in Google Code wiki format::
    
    python setup.py publish_docs --google-user=x --google-password=x

Just use literally "x" for user / pass since logging in and publishing is not implemented.  Yea!