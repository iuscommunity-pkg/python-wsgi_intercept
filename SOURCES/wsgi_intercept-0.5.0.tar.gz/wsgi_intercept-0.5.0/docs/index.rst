===============================================================================
wsgi_intercept: installs a WSGI application in place of a real URI for testing.
===============================================================================

.. contents::

.. include_docstring:: ./wsgi_intercept/__init__.py

